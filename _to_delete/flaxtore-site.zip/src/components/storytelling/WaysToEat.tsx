import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { StaggerItem, Stagger } from "@/components/motion/Stagger";

const ways = [
  "Straight from the pouch",
  "Stirred into yogurt",
  "Scattered over oats",
  "Blended into a smoothie",
  "Folded into a breakfast bowl",
  "Tossed over a salad",
  "Mixed into a snack mix",
];

export function WaysToEat() {
  return (
    <section className="bg-cream py-24 md:py-32">
      <Container>
        <SectionHeading
          eyebrow="Ways To Eat It"
          title="Seven ways in. Zero rules."
          align="center"
        />
        <Stagger gap={0.06} className="mx-auto mt-14 flex max-w-4xl flex-wrap items-center justify-center gap-3">
          {ways.map((way) => (
            <StaggerItem key={way}>
              <span className="inline-flex items-center rounded-[var(--radius-pill)] border border-border-strong bg-surface px-5 py-3 font-display text-base text-ink shadow-[var(--shadow-sm)] md:text-lg">
                {way}
              </span>
            </StaggerItem>
          ))}
        </Stagger>
      </Container>
    </section>
  );
}
