import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { StaggerItem, Stagger } from "@/components/motion/Stagger";
import { PlaceholderImage } from "@/components/ui/PlaceholderImage";

const steps = [
  {
    step: "01",
    title: "Seeds",
    copy: "Raw flaxseed arrives in bulk, straight from the harvest.",
  },
  {
    step: "02",
    title: "Selection",
    copy: "Optical Sortex sorting separates by size, colour and quality.",
  },
  {
    step: "03",
    title: "Cleaning",
    copy: "Broken seeds, husks and foreign material are removed.",
  },
  {
    step: "04",
    title: "Quality",
    copy: "What's left is a consistent batch, ready for the roaster.",
  },
];

export function SortexStory() {
  return (
    <section className="bg-cream py-24 md:py-32">
      <Container>
        <SectionHeading
          eyebrow="The Process — Part One"
          title="Sortex-cleaned, before anything else."
          description="An unglamorous step that decides everything after it. We start every batch here, not because it's exciting, but because it isn't optional."
        />

        <Stagger gap={0.1} className="mt-16 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {steps.map((s) => (
            <StaggerItem key={s.step} className="flex flex-col gap-4">
              <div className="aspect-square overflow-hidden rounded-[var(--radius-lg)]">
                <PlaceholderImage label={`0${s.step} — pending photography`} />
              </div>
              <div>
                <span className="text-xs font-semibold uppercase tracking-[0.16em] text-brand-500">
                  {s.step}
                </span>
                <h3 className="mt-1 font-display text-xl text-ink">{s.title}</h3>
                <p className="mt-1 text-sm leading-relaxed text-ink-muted">{s.copy}</p>
              </div>
            </StaggerItem>
          ))}
        </Stagger>
      </Container>
    </section>
  );
}
