import type { Metadata } from "next";
import { Hero } from "@/components/hero/Hero";
import { BrandPromise } from "@/components/storytelling/BrandPromise";
import { ProductIntro } from "@/components/storytelling/ProductIntro";
import { CrunchStory } from "@/components/storytelling/CrunchStory";
import { SortexStory } from "@/components/storytelling/SortexStory";
import { RoastingStory } from "@/components/storytelling/RoastingStory";
import { FlavourExperience } from "@/components/product/FlavourExperience";
import { NutritionSection } from "@/components/storytelling/NutritionSection";
import { LifestyleStory } from "@/components/storytelling/LifestyleStory";
import { WellnessStory } from "@/components/storytelling/WellnessStory";
import { WaysToEat } from "@/components/storytelling/WaysToEat";
import { SocialProof } from "@/components/storytelling/SocialProof";
import { BrandStory } from "@/components/storytelling/BrandStory";
import { FAQSection } from "@/components/storytelling/FAQSection";
import { FinalCTA } from "@/components/storytelling/FinalCTA";
import { commerce } from "@/lib/commerce";

export const metadata: Metadata = {
  alternates: { canonical: "/" },
};

export default async function HomePage() {
  const products = await commerce.getFeaturedProducts();

  return (
    <>
      <Hero />
      <BrandPromise />
      <ProductIntro />
      <CrunchStory />
      <SortexStory />
      <RoastingStory />
      <FlavourExperience products={products} />
      <NutritionSection />
      <LifestyleStory />
      <WellnessStory />
      <WaysToEat />
      <SocialProof />
      <BrandStory />
      <FAQSection />
      <FinalCTA />
    </>
  );
}
